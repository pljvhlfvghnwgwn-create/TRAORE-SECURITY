# TRAORE SECURITY

Application Android de détection de mouvement et d'alarme, avec protection antivol par capteurs et modules cloud optionnels.

## Compilation rapide depuis un téléphone
1. Téléverse le contenu du dossier `TRAORE-SECURITY` dans un dépôt GitHub, en conservant toute l'arborescence.
2. Ouvre l'onglet **Actions** et exécute **Build TRAORE SECURITY APK** (ou pousse un commit sur `main`).
3. Lorsque le workflow réussit, télécharge l'artefact `traore-security-debug-apk`.
4. Installe l'APK de test sur ton téléphone. Autorise caméra et notifications si tu actives ces fonctions.

Le workflow compile l'application Android en mode debug. Ce n'est pas un APK de production signé.

## Firebase (facultatif pour la base locale)
Consulte `firebase/CONFIGURATION.md`, place `google-services.json` dans `app/`, puis configure `.firebaserc` à partir de `.firebaserc.example`. Déploie ensuite les règles et la Cloud Function avec la Firebase CLI depuis un environnement compatible.

## Limites
La détection caméra fonctionne lorsque l'application est ouverte. Le transfert des médias vers le cloud est déclenché manuellement depuis la galerie. La configuration Firebase et les tests sur deux téléphones sont nécessaires pour les alertes et la galerie distante. Voir `ETAT-DU-PROJET.md`.

**Ne pas utiliser comme unique système de sécurité tant que la compilation et les tests en conditions réelles ne sont pas terminés.**
