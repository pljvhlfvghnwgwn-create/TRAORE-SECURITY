# TRAORE SECURITY — état consolidé

## Inclus dans cette archive
- Application Android Kotlin et interface française.
- Détection caméra lorsque l'application est ouverte, alarme, photos/vidéos et historique local.
- Protection antivol par capteurs avec notification persistante (à tester sur appareil réel).
- Connexion/création de compte Firebase et association du jeton FCM à l'utilisateur.
- Événements cloud et fonction serveur de notification aux appareils enregistrés.
- Galerie locale avec action explicite d'envoi d'un média vers Firebase Storage.
- Liste des médias distants et ouverture du média depuis le lien Firebase.
- Règles Firestore/Storage, `firebase.json` et workflow GitHub Actions pour compiler un APK debug.

## Configuration obligatoire avant compilation et usage cloud
1. Créer un projet Firebase et enregistrer l'application Android `com.traore.security`.
2. Télécharger `google-services.json` et le placer dans `app/google-services.json`.
3. Activer l'authentification e-mail/mot de passe, Firestore, Storage et Cloud Messaging.
4. Remplacer le projet par défaut via `.firebaserc` (copier `.firebaserc.example` puis modifier l'identifiant).
5. Installer les dépendances serveur (`cd functions && npm install`) et déployer les règles et fonctions (`firebase deploy`).
6. Compiler via GitHub Actions et tester avec deux appareils et un compte de test.

## Limites connues — ne pas considérer comme un système de sécurité garanti
- La caméra n'est surveillée que lorsque l'application est ouverte; la surveillance caméra permanente écran éteint n'est pas implémentée.
- Le transfert des médias vers le cloud est manuel depuis la galerie; il n'est pas automatiquement déclenché par chaque détection.
- La galerie distante exige une configuration Firebase valide et une connexion au même compte sur les appareils.
- Le code n'a pas été compilé ni testé sur appareil réel dans cet environnement. La génération d'un APK via GitHub Actions est à effectuer.
- Les liens de téléchargement Firebase doivent être protégés par des règles et ne doivent être partagés qu'avec des personnes autorisées.
