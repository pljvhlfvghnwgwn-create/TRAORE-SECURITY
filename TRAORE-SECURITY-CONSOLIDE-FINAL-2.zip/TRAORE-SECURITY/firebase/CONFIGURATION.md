# Configuration Firebase — TRAORE SECURITY

## Configuration requise
1. Créer un projet Firebase et ajouter une application Android avec l'identifiant `com.traore.security`.
2. Télécharger `google-services.json` dans le dossier `app/`.
3. Activer Authentication (e-mail/mot de passe), Cloud Firestore, Storage et Cloud Messaging.
4. Déployer les règles proposées dans `firestore.rules` et `storage.rules` après vérification dans le simulateur de règles.
5. Installer Firebase CLI et Node.js 20 dans un environnement de développement, puis déployer `functions/` avec un projet Firebase sélectionné.
6. Utiliser le même compte sur les deux téléphones pour associer les appareils. Les jetons FCM doivent être envoyés uniquement à Firestore sous l'identité authentifiée.

## Sécurité
- Ne jamais mettre une clé de compte de service Firebase Admin dans l'application ou dans GitHub.
- Ne pas ouvrir Firestore/Storage au public.
- Restreindre les médias au propriétaire authentifié et tester les règles avant d'y déposer des enregistrements privés.
- Informer les personnes filmées et respecter la loi applicable.

## État réel
Les règles et la fonction serveur sont préparées dans cette archive. L'application Android ne raccorde pas encore automatiquement l'authentification, l'inscription des jetons FCM, la création des alertes cloud ni l'affichage de la galerie distante. Il faut configurer Firebase puis compléter et tester ces liaisons avant de compter sur les alertes à distance.
