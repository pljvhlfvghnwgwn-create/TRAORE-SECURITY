# Galerie et alertes à distance

Le même compte Firebase doit être utilisé sur le téléphone surveillant et le téléphone récepteur. Chaque téléphone connecté enregistre son jeton FCM dans `users/{uid}/devices/{deviceId}`. Le serveur `functions/notifyPairedDevices` envoie les alertes créées dans `users/{uid}/alerts/{alertId}` aux appareils enregistrés pour ce compte.

Les photos/vidéos sont stockées dans `users/{uid}/media/` via Firebase Storage et référencées dans Firestore. Les règles proposées limitent la lecture et l'écriture au propriétaire authentifié. Ne jamais utiliser des règles publiques.

Cette archive prépare les règles et la fonction serveur, mais l'écran de connexion, l'enregistrement automatique des jetons, la création des documents d'alerte et l'affichage/téléchargement des médias distants doivent encore être raccordés à l'application Android. Ne pas considérer la fonction distante comme active avant configuration et tests sur deux appareils.
