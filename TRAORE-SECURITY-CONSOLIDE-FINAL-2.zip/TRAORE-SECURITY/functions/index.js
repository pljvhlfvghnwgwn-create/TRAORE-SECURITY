const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();

// An authenticated device creates an alert under its own account.
// Tokens are stored under users/{uid}/devices/{deviceId}; only the server sends FCM.
exports.notifyPairedDevices = onDocumentCreated('users/{uid}/alerts/{alertId}', async (event) => {
  const { uid } = event.params;
  const alert = event.data?.data() || {};
  const db = getFirestore();
  const devices = await db.collection('users').doc(uid).collection('devices').get();
  const tokens = devices.docs.map((doc) => doc.get('fcmToken')).filter((token) => typeof token === 'string' && token.length > 0);
  if (!tokens.length) return;

  const title = typeof alert.title === 'string' ? alert.title.slice(0, 80) : 'TRAORE SECURITY';
  const body = typeof alert.body === 'string' ? alert.body.slice(0, 180) : 'Un mouvement a été détecté.';
  const response = await getMessaging().sendEachForMulticast({
    tokens,
    notification: { title, body },
    data: { alertId: String(event.params.alertId) },
    android: { priority: 'high' }
  });

  // Remove invalid tokens so future sends stay healthy.
  const removals = [];
  response.responses.forEach((result, index) => {
    const code = result.error?.code || '';
    if (code.includes('registration-token-not-registered') || code.includes('invalid-registration-token')) {
      const deviceDoc = devices.docs.find((doc) => doc.get('fcmToken') === tokens[index]);
      if (deviceDoc) removals.push(deviceDoc.ref.delete());
    }
  });
  await Promise.all(removals);
});
