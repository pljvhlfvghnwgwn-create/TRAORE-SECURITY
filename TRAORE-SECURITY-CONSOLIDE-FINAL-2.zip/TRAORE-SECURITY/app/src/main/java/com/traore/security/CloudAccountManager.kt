package com.traore.security

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import java.util.UUID

/** Handles opt-in account sign-in and pairing of this device with the same account. */
class CloudAccountManager(private val context: Context) {
    fun configured(): Boolean = FirebaseApp.getApps(context).isNotEmpty()

    fun signInOrCreate(email: String, password: String, create: Boolean, callback: (Result<String>) -> Unit) {
        if (!configured()) {
            callback(Result.failure(IllegalStateException("Firebase n'est pas configuré. Ajoute app/google-services.json et active Authentification e-mail/mot de passe.")))
            return
        }
        if (email.isBlank() || password.length < 6) {
            callback(Result.failure(IllegalArgumentException("Saisis un e-mail et un mot de passe d'au moins 6 caractères.")))
            return
        }
        val auth = FirebaseAuth.getInstance()
        val task = if (create) auth.createUserWithEmailAndPassword(email.trim(), password)
                   else auth.signInWithEmailAndPassword(email.trim(), password)
        task.addOnSuccessListener {
            registerThisDevice { result ->
                result.fold({ callback(Result.success("Compte connecté. Ce téléphone est associé aux alertes.")) },
                    { callback(Result.failure(it)) })
            }
        }.addOnFailureListener { callback(Result.failure(it)) }
    }

    fun registerThisDevice(callback: (Result<Unit>) -> Unit = {}) {
        if (!configured()) { callback(Result.failure(IllegalStateException("Firebase non configuré."))); return }
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) { callback(Result.failure(IllegalStateException("Connecte-toi d'abord."))); return }
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            val prefs = context.getSharedPreferences("traore_security", Context.MODE_PRIVATE)
            val deviceId = prefs.getString("cloud_device_id", null) ?: UUID.randomUUID().toString().also {
                prefs.edit().putString("cloud_device_id", it).apply()
            }
            val record = mapOf("fcmToken" to token, "platform" to "android", "updatedAt" to System.currentTimeMillis())
            FirebaseFirestore.getInstance().collection("users").document(user.uid)
                .collection("devices").document(deviceId).set(record)
                .addOnSuccessListener { callback(Result.success(Unit)) }
                .addOnFailureListener { callback(Result.failure(it)) }
        }.addOnFailureListener { callback(Result.failure(it)) }
    }

    fun sendAlert(title: String, body: String) {
        if (!configured()) return
        val user = FirebaseAuth.getInstance().currentUser ?: return
        FirebaseFirestore.getInstance().collection("users").document(user.uid)
            .collection("alerts").add(mapOf(
                "title" to title.take(80), "body" to body.take(180),
                "createdAt" to System.currentTimeMillis(), "source" to "android"
            ))
    }
}
