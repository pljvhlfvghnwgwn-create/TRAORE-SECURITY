package com.traore.security

import android.content.Context
import android.net.Uri
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.io.File

/**
 * Firebase cloud-media adapter. It stays inactive until the app is configured with
 * google-services.json and the signed-in user has permission under Firebase rules.
 * Uploading media is explicit; do not upload private recordings without user consent.
 */
class CloudMediaRepository(private val context: Context) {
    data class RemoteMedia(
        val name: String = "",
        val type: String = "",
        val downloadUrl: String = "",
        val createdAt: Long = 0L
    )

    private fun isConfigured(): Boolean = FirebaseApp.getApps(context).isNotEmpty()

    fun upload(file: File, type: String, onResult: (Result<String>) -> Unit) {
        if (!isConfigured()) {
            onResult(Result.failure(IllegalStateException("Firebase n'est pas configuré. Ajoute google-services.json et configure le projet Firebase.")))
            return
        }
        if (!file.exists() || !file.isFile) {
            onResult(Result.failure(IllegalArgumentException("Fichier introuvable.")))
            return
        }
        val userId = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid
        if (userId.isNullOrBlank()) {
            onResult(Result.failure(IllegalStateException("Connecte-toi avant d'envoyer un média.")))
            return
        }
        val safeName = file.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val ref = FirebaseStorage.getInstance().reference.child("users/$userId/media/${System.currentTimeMillis()}_$safeName")
        ref.putFile(Uri.fromFile(file)).continueWithTask { task ->
            if (!task.isSuccessful) throw task.exception ?: IllegalStateException("Échec de l'envoi")
            ref.downloadUrl
        }.addOnSuccessListener { url ->
            val record = mapOf("name" to file.name, "type" to type, "downloadUrl" to url.toString(), "createdAt" to System.currentTimeMillis())
            FirebaseFirestore.getInstance().collection("users").document(userId)
                .collection("media").add(record)
                .addOnSuccessListener { onResult(Result.success(url.toString())) }
                .addOnFailureListener { onResult(Result.failure(it)) }
        }.addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun list(onResult: (Result<List<RemoteMedia>>) -> Unit) {
        if (!isConfigured()) {
            onResult(Result.failure(IllegalStateException("Firebase n'est pas configuré.")))
            return
        }
        val userId = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid
        if (userId.isNullOrBlank()) {
            onResult(Result.failure(IllegalStateException("Connecte-toi pour consulter la galerie distante.")))
            return
        }
        FirebaseFirestore.getInstance().collection("users").document(userId).collection("media")
            .get()
            .addOnSuccessListener { snapshot ->
                val items = snapshot.documents.mapNotNull { doc -> doc.toObject(RemoteMedia::class.java) }
                    .sortedByDescending { it.createdAt }
                onResult(Result.success(items))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }
}
