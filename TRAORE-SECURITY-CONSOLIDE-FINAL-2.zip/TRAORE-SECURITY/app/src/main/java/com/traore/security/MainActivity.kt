package com.traore.security

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.RadioButton
import android.app.AlertDialog
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var historyText: TextView
    private lateinit var previewView: PreviewView
    private var cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var tone: ToneGenerator? = null
    private var cameraOn = false
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var antiTheftArmed = false
    private var sensitivity = 24
    private var lastAlertAt = 0L
    private var lastFrameAverage: Double? = null
    private val events = mutableListOf<String>()

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera() else toast("Autorisation caméra refusée.")
        if (Build.VERSION.SDK_INT >= 33 && result[Manifest.permission.POST_NOTIFICATIONS] != true) {
            toast("Les notifications pourront être limitées sans autorisation.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
        buildInterface()
        requestPermissionsIfNeeded()
        loadHistory()
    }

    private fun buildInterface() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 22)
            setBackgroundColor(Color.rgb(7, 19, 13))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "TRAORE SECURITY"
            textSize = 27f
            setTextColor(Color.rgb(56, 193, 114))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 4)
        }
        val subtitle = TextView(this).apply {
            text = "Détection de mouvement • Sécurité mobile"
            textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        status = TextView(this).apply {
            text = "ÉTAT : prêt"
            textSize = 16f; setTextColor(Color.WHITE)
            setPadding(12, 14, 12, 14)
            setBackgroundColor(Color.rgb(20, 47, 31))
        }
        previewView = PreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 420).apply { setMargins(0, 14, 0, 14) }
            visibility = View.GONE
        }
        content.addView(title); content.addView(subtitle); content.addView(status); content.addView(previewView)
        content.addView(actionButton("▶ Démarrer la surveillance caméra") { toggleCamera() })
        content.addView(actionButton("📸 Prendre une photo") { takePhoto() })
        content.addView(actionButton("🎬 Démarrer / arrêter la vidéo") { toggleVideoRecording() })
        content.addView(actionButton("☁️ Compte cloud / associer ce téléphone") { showCloudAccountDialog() })
        content.addView(actionButton("🖼️ Ouvrir la galerie des médias") {
            startActivity(android.content.Intent(this, GalleryActivity::class.java))
        })
        content.addView(actionButton("🛡 Activer / désactiver l'antivol") { toggleAntiTheft() })
        content.addView(actionButton("🔊 Tester l'alarme") { triggerAlarm("Test manuel") })
        content.addView(actionButton("🔕 Arrêter l'alarme") { stopAlarm() })
        content.addView(actionButton("🎚 Sensibilité : modifier") {
            sensitivity = when (sensitivity) { 24 -> 15; 15 -> 35; else -> 24 }
            toast("Sensibilité réglée sur $sensitivity")
            updateStatus()
        })
        val historyTitle = TextView(this).apply {
            text = "HISTORIQUE DES DÉTECTIONS"; textSize = 16f; setTextColor(Color.rgb(56, 193, 114))
            setPadding(0, 22, 0, 8)
        }
        historyText = TextView(this).apply { textSize = 13f; setTextColor(Color.WHITE); setPadding(0, 0, 0, 18) }
        content.addView(historyTitle); content.addView(historyText)
        val footnote = TextView(this).apply {
            text = "La caméra fonctionne lorsque l’application est ouverte. Le cloud exige la configuration Firebase. Teste toujours la surveillance et les alertes avant de t’y fier."
            textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 12, 0, 20)
        }
        content.addView(footnote)
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false
        setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(22, 132, 71))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 6, 0, 6) }
        setOnClickListener { action() }
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }

    private fun showCloudAccountDialog() {
        val cloud = CloudAccountManager(this)
        if (!cloud.configured()) {
            AlertDialog.Builder(this).setTitle("Configuration cloud requise")
                .setMessage("Pour recevoir les alertes sur un deuxième téléphone, crée un projet Firebase, active Authentification par e-mail/mot de passe et ajoute le fichier google-services.json dans le dossier app/. Les étapes sont dans firebase/CONFIGURATION.md.")
                .setPositiveButton("Compris", null).show()
            return
        }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 8, 36, 0) }
        val email = EditText(this).apply { hint = "Adresse e-mail"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS }
        val password = EditText(this).apply { hint = "Mot de passe (6 caractères minimum)"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val mode = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            addView(RadioButton(this@MainActivity).apply { text = "Se connecter"; id = 1; isChecked = true })
            addView(RadioButton(this@MainActivity).apply { text = "Créer un compte"; id = 2 })
        }
        panel.addView(email); panel.addView(password); panel.addView(mode)
        AlertDialog.Builder(this).setTitle("Compte cloud sécurisé").setView(panel)
            .setPositiveButton("Continuer", null).setNegativeButton("Annuler", null).create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val create = mode.checkedRadioButtonId == 2
                        cloud.signInOrCreate(email.text.toString(), password.text.toString(), create) { result ->
                            runOnUiThread {
                                result.fold({ toast(it); dialog.dismiss() }, { toast("Connexion impossible : ${it.localizedMessage ?: "erreur inconnue"}") })
                            }
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun toggleCamera() {
        if (cameraOn) {
            activeRecording?.stop(); activeRecording = null
            ProcessCameraProvider.getInstance(this).get().unbindAll()
            imageCapture = null; videoCapture = null
            cameraOn = false; previewView.visibility = View.GONE
            addEvent("Surveillance caméra arrêtée"); updateStatus()
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else requestPermissionsIfNeeded()
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(cameraExecutor) { image -> analyzeFrame(image) }
                val capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                val recorder = Recorder.Builder().build()
                val video = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis, capture, video)
                imageCapture = capture
                videoCapture = video
                cameraOn = true; previewView.visibility = View.VISIBLE
                addEvent("Surveillance caméra démarrée"); updateStatus()
            } catch (e: Exception) { toast("Impossible de démarrer la caméra : ${e.localizedMessage}") }
        }, ContextCompat.getMainExecutor(this))
    }


    private fun outputDirectory(folder: String): File {
        val base = getExternalFilesDir(folder) ?: filesDir
        if (!base.exists()) base.mkdirs()
        return base
    }

    private fun fileStamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun takePhoto() {
        val capture = imageCapture
        if (!cameraOn || capture == null) {
            toast("Démarre d'abord la surveillance caméra.")
            return
        }
        val photo = File(outputDirectory("Pictures"), "TRAORE_${fileStamp()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(photo).build()
        capture.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                runOnUiThread {
                    addEvent("Photo enregistrée : ${photo.name}")
                    toast("Photo enregistrée dans les fichiers de l'application.")
                }
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { toast("Échec de la photo : ${exception.message}") }
            }
        })
    }

    private fun toggleVideoRecording() {
        if (activeRecording != null) {
            activeRecording?.stop()
            activeRecording = null
            toast("Arrêt de l'enregistrement vidéo.")
        } else {
            startVideoRecording()
        }
    }

    private fun startVideoRecording(autoStopAfterMs: Long? = null) {
        val capture = videoCapture
        if (!cameraOn || capture == null) {
            toast("Démarre d'abord la surveillance caméra.")
            return
        }
        if (activeRecording != null) return
        val videoFile = File(outputDirectory("Movies"), "TRAORE_${fileStamp()}.mp4")
        val outputOptions = FileOutputOptions.Builder(videoFile).build()
        activeRecording = capture.output.prepareRecording(this, outputOptions)
            .start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        addEvent("Enregistrement vidéo démarré")
                        if (autoStopAfterMs == null) toast("Enregistrement vidéo en cours.")
                    }
                    is VideoRecordEvent.Finalize -> {
                        activeRecording = null
                        if (event.hasError()) {
                            addEvent("Erreur d'enregistrement vidéo (${event.error})")
                            toast("Erreur pendant l'enregistrement vidéo.")
                        } else {
                            addEvent("Vidéo enregistrée : ${videoFile.name}")
                            if (autoStopAfterMs == null) toast("Vidéo enregistrée dans les fichiers de l'application.")
                        }
                    }
                }
            }
        if (autoStopAfterMs != null) {
            mainHandler.postDelayed({ activeRecording?.stop() }, autoStopAfterMs)
        }
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            val plane = image.planes.firstOrNull() ?: return
            val buffer = plane.buffer
            val bytes = ByteArray(buffer.remaining()); buffer.get(bytes)
            if (bytes.isEmpty()) return
            var sum = 0L
            val step = maxOf(1, bytes.size / 1500)
            var count = 0
            var i = 0
            while (i < bytes.size) { sum += (bytes[i].toInt() and 0xFF); count++; i += step }
            val avg = sum.toDouble() / maxOf(1, count)
            val old = lastFrameAverage
            lastFrameAverage = avg
            if (old != null && abs(avg - old) > sensitivity && SystemClock.elapsedRealtime() - lastAlertAt > 5000) {
                lastAlertAt = SystemClock.elapsedRealtime()
                runOnUiThread { triggerAlarm("Mouvement détecté par caméra") }
            }
        } catch (_: Exception) { } finally { image.close() }
    }

    private fun toggleAntiTheft() {
        antiTheftArmed = !antiTheftArmed
        getSharedPreferences("traore_security", MODE_PRIVATE).edit().putBoolean("antitheft_armed", antiTheftArmed).apply()
        if (antiTheftArmed) {
            val intent = android.content.Intent(this, AntiTheftService::class.java).setAction(AntiTheftService.ACTION_START)
            try {
                ContextCompat.startForegroundService(this, intent)
                addEvent("Protection antivol activée")
                toast("Antivol activé. Pose le téléphone sans le déplacer.")
            } catch (e: Exception) {
                antiTheftArmed = false
                toast("Impossible d'activer l'antivol : ${e.localizedMessage}")
            }
        } else {
            stopService(android.content.Intent(this, AntiTheftService::class.java))
            addEvent("Protection antivol désactivée")
            stopAlarm()
        }
        updateStatus()
    }

    @Suppress("DEPRECATION")
    private fun triggerAlarm(reason: String) {
        lastAlertAt = SystemClock.elapsedRealtime()
        try { tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1500) } catch (_: Exception) { }
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(android.os.VibrationEffect.createOneShot(700, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") vibrator.vibrate(700)
        } catch (_: Exception) { }
        addEvent(reason)
        status.text = "⚠ ALERTE : $reason"
        status.setTextColor(Color.YELLOW)
        postNotification(reason)
        CloudAccountManager(this).sendAlert("TRAORE SECURITY", reason)
        if (reason.contains("caméra", ignoreCase = true)) {
            takePhoto()
            if (activeRecording == null) startVideoRecording(15_000L)
        }
    }

    private fun stopAlarm() {
        try { tone?.stopTone() } catch (_: Exception) { }
        addEvent("Alarme arrêtée"); updateStatus()
    }

    private fun postNotification(message: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        val channelId = "traore_security_alerts"
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(android.app.NotificationChannel(channelId, "Alertes de sécurité", android.app.NotificationManager.IMPORTANCE_HIGH))
        val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, channelId) else android.app.Notification.Builder(this)
        manager.notify(1001, notification.setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("TRAORE SECURITY").setContentText(message).setAutoCancel(true).build())
    }

    private fun addEvent(message: String) {
        val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        events.add(0, "$stamp — $message")
        while (events.size > 30) events.removeAt(events.lastIndex)
        getSharedPreferences("traore_security", MODE_PRIVATE).edit().putString("events", events.joinToString("\n")).apply()
        if (::historyText.isInitialized) historyText.text = events.joinToString("\n\n").ifBlank { "Aucun événement pour le moment." }
    }

    private fun loadHistory() {
        val saved = getSharedPreferences("traore_security", MODE_PRIVATE).getString("events", "").orEmpty()
        events.clear(); if (saved.isNotBlank()) events.addAll(saved.split("\n").take(30))
        historyText.text = events.joinToString("\n\n").ifBlank { "Aucun événement pour le moment." }
    }

    private fun updateStatus() {
        status.setTextColor(Color.WHITE)
        status.text = "CAMÉRA : ${if (cameraOn) "ACTIVE" else "ARRÊTÉE"}   •   ANTIVOL : ${if (antiTheftArmed) "ACTIF" else "INACTIF"}\nSensibilité : $sensitivity"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onResume() { super.onResume(); antiTheftArmed = getSharedPreferences("traore_security", MODE_PRIVATE).getBoolean("antitheft_armed", false); updateStatus() }
    override fun onPause() { super.onPause() }
    override fun onDestroy() { activeRecording?.stop(); activeRecording = null; super.onDestroy(); try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Exception) { }; cameraExecutor.shutdown(); tone?.release() }
}
