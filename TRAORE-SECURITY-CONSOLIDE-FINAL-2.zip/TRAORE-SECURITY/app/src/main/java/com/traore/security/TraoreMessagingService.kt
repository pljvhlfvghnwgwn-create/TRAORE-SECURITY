package com.traore.security

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** Receives remote alerts. A trusted server must send messages to registered devices. */
class TraoreMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        // Store the token only in the authenticated user's private device collection.
        CloudAccountManager(applicationContext).registerThisDevice()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: "TRAORE SECURITY"
        val body = message.notification?.body ?: message.data["body"] ?: "Nouvelle alerte de sécurité."
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = "traore_remote_alerts"
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channel, "Alertes à distance", NotificationManager.IMPORTANCE_HIGH))
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(title).setContentText(body).setAutoCancel(true).build())
    }
}
