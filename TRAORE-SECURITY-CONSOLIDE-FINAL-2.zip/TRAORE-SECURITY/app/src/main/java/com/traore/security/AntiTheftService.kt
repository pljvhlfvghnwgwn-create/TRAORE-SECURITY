package com.traore.security

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sqrt

/** User-activated foreground service for movement-based phone anti-theft alerts. */
class AntiTheftService : Service(), SensorEventListener {
    companion object {
        const val ACTION_START = "com.traore.security.action.START_ANTITHEFT"
        private const val CHANNEL_ID = "traore_antitheft_monitor"
        private const val NOTIFICATION_ID = 4102
    }

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var lastMagnitude = 0f
    private var baselineReady = false
    private var lastAlertAt = 0L
    private var tone: ToneGenerator? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification("Protection antivol active"))
        val sensor = accelerometer
        if (sensor == null) {
            alertNotification("Capteur de mouvement indisponible")
            stopSelf()
            return START_NOT_STICKY
        }
        sensorManager.unregisterListener(this)
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        getSharedPreferences("traore_security", MODE_PRIVATE).edit().putBoolean("antitheft_armed", true).apply()
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
        val magnitude = sqrt(x * x + y * y + z * z)
        if (!baselineReady) {
            lastMagnitude = magnitude
            baselineReady = true
            return
        }
        val delta = abs(magnitude - lastMagnitude)
        lastMagnitude = magnitude
        val now = SystemClock.elapsedRealtime()
        if (delta > 2.8f && now - lastAlertAt > 5000L) {
            lastAlertAt = now
            try { tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1800) } catch (_: Exception) { }
            try {
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(900, VibrationEffect.DEFAULT_AMPLITUDE))
                else @Suppress("DEPRECATION") vibrator.vibrate(900)
            } catch (_: Exception) { }
            alertNotification("Mouvement détecté : vérifie ton téléphone")
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Protection antivol", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun buildNotification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("TRAORE SECURITY")
            .setContentText(text)
            .setOngoing(true)
            .build()
    }

    private fun alertNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID + 1, buildNotification(text))
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        getSharedPreferences("traore_security", MODE_PRIVATE).edit().putBoolean("antitheft_armed", false).apply()
        try { tone?.stopTone(); tone?.release() } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
