package com.traore.security

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Galerie locale et distante. Le transfert cloud est déclenché manuellement par l'utilisateur. */
class GalleryActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var cloudList: LinearLayout
    private lateinit var summary: TextView
    private val mediaRepository by lazy { CloudMediaRepository(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 22)
            setBackgroundColor(Color.rgb(7, 19, 13))
        }
        val title = TextView(this).apply {
            text = "TRAORE SECURITY — GALERIE"
            textSize = 22f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(56, 193, 114)); setPadding(0, 8, 0, 18)
        }
        summary = TextView(this).apply { textSize = 14f; setTextColor(Color.WHITE); setPadding(0, 0, 0, 12) }
        val refresh = Button(this).apply {
            text = "Actualiser les galeries"
            setOnClickListener { loadLocalMedia(); loadRemoteMedia() }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cloudList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(summary)
        content.addView(sectionTitle("GALERIE LOCALE — photos et vidéos"))
        content.addView(list)
        content.addView(sectionTitle("GALERIE À DISTANCE — compte Firebase"))
        content.addView(TextView(this).apply {
            text = "Connecte-toi au même compte sur les deux téléphones. Les médias locaux ne sont envoyés qu'après avoir appuyé sur Envoyer vers le cloud."
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(4, 6, 4, 12)
        })
        content.addView(cloudList)
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(title); root.addView(refresh); root.addView(scroll)
        setContentView(root)
        loadLocalMedia()
        loadRemoteMedia()
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value; textSize = 16f; setTextColor(Color.rgb(56, 193, 114)); setPadding(4, 16, 4, 8)
    }

    private fun loadLocalMedia() {
        list.removeAllViews()
        val photos = mediaFiles("Pictures", listOf("jpg", "jpeg", "png"))
        val videos = mediaFiles("Movies", listOf("mp4", "mov", "3gp"))
        summary.text = "Photos : ${photos.size}   •   Vidéos : ${videos.size}"
        addLocalSection("PHOTOS", photos, "photo")
        addLocalSection("VIDÉOS", videos, "video")
        if (photos.isEmpty() && videos.isEmpty()) addLine(list, "Aucun média local enregistré.")
    }

    private fun mediaFiles(folder: String, extensions: List<String>): List<File> =
        File(getExternalFilesDir(folder)?.path ?: filesDir.path).listFiles()
            ?.filter { it.isFile && it.extension.lowercase(Locale.ROOT) in extensions }
            ?.sortedByDescending { it.lastModified() }.orEmpty()

    private fun addLocalSection(title: String, files: List<File>, type: String) {
        addLine(list, "\n$title (${files.size})", true)
        files.forEach { file ->
            val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(file.lastModified()))
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 8, 4, 12) }
            row.addView(TextView(this).apply {
                text = "${file.name}\n$date • ${file.length() / 1024} Ko"
                textSize = 13f; setTextColor(Color.WHITE)
            })
            row.addView(Button(this).apply {
                text = "Envoyer vers le cloud"
                setOnClickListener {
                    isEnabled = false
                    mediaRepository.upload(file, type) { result -> runOnUiThread {
                        isEnabled = true
                        result.fold({
                            Toast.makeText(this@GalleryActivity, "Média envoyé vers le cloud.", Toast.LENGTH_LONG).show()
                            loadRemoteMedia()
                        }, { error -> Toast.makeText(this@GalleryActivity, error.message ?: "Échec de l'envoi", Toast.LENGTH_LONG).show() })
                    } }
                }
            })
            list.addView(row)
        }
    }

    private fun loadRemoteMedia() {
        cloudList.removeAllViews()
        mediaRepository.list { result -> runOnUiThread {
            cloudList.removeAllViews()
            result.fold({ items ->
                if (items.isEmpty()) addLine(cloudList, "Aucun média distant. Envoie un média depuis la galerie locale.")
                items.forEach { item ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 8, 4, 12) }
                    val date = if (item.createdAt > 0) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(item.createdAt)) else "Date inconnue"
                    row.addView(TextView(this).apply {
                        text = "${item.name}\n${item.type} • $date"
                        textSize = 13f; setTextColor(Color.WHITE)
                    })
                    row.addView(Button(this).apply {
                        text = "Ouvrir le média"
                        setOnClickListener {
                            if (item.downloadUrl.isBlank()) Toast.makeText(this@GalleryActivity, "Lien du média indisponible.", Toast.LENGTH_SHORT).show()
                            else try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.downloadUrl))) }
                            catch (_: Exception) { Toast.makeText(this@GalleryActivity, "Aucune application ne peut ouvrir ce média.", Toast.LENGTH_SHORT).show() }
                        }
                    })
                    cloudList.addView(row)
                }
            }, { error -> addLine(cloudList, error.message ?: "Galerie distante indisponible. Configure Firebase et connecte-toi.") })
        } }
    }

    private fun addLine(target: LinearLayout, value: String, heading: Boolean = false) {
        target.addView(TextView(this).apply {
            text = value; textSize = if (heading) 16f else 13f
            setTextColor(if (heading) Color.rgb(56, 193, 114) else Color.WHITE)
            setPadding(4, 8, 4, 8)
        }, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
}
